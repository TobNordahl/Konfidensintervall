function testfunc(name){
    console.log(name);
}